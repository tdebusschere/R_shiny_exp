###R server
library(shiny)

# Define server logic required to plot various variables against mpg
shinyServer(function(input, output) {

})

